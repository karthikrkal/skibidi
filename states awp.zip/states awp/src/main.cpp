#include "vex.h"
#include "vex_smartdrive.h"
using namespace vex;
using signature = vision::signature;
using code = vision::code;
competition Competition;
brain Brain;

motor leftMotorA = motor(PORT11, ratio6_1, true);
motor leftMotorB = motor(PORT12, ratio6_1, false);
motor leftMotorC = motor(PORT13, ratio6_1, true);
motor rightMotorA = motor(PORT14, ratio6_1, false);
motor rightMotorB = motor(PORT15, ratio6_1, true);
motor rightMotorC = motor(PORT16, ratio6_1, false);
motor_group LDrive = motor_group(leftMotorA, leftMotorB, leftMotorC);
motor_group RDrive = motor_group(rightMotorA, rightMotorB, rightMotorC);
inertial monkeyDir = inertial(PORT19); //inertial
smartdrive Monkey = smartdrive(LDrive, RDrive, monkeyDir, 220, 368.3, 330.2, mm, 0.75);
motor bananaEater = motor(PORT17, ratio6_1, false); //intake
motor bananaShooter = motor(PORT18, ratio36_1, true); //cata
distance bananaSeer = distance(PORT20); //distance sensor on cata
digital_out bananaPusherVertical = digital_out(Brain.ThreeWirePort.A); //wings
digital_out intakeRelease = digital_out(Brain.ThreeWirePort.B); //pistons on intake
digital_out thumbs = digital_out(Brain.ThreeWirePort.C); //hang
digital_out horizontal_wing_1 = digital_out(Brain.ThreeWirePort.D);
digital_out horizontal_wing_2 = digital_out(Brain.ThreeWirePort.E);
controller realMonkey = controller(primary); //controller

const double flywheelSpeed = 12;
void pre_auton(void) {
}

//90 deg at blue goal, 180 at red, 270 at 

void autonomous(void) {
  //35 sec
  wait (3, sec);
  Monkey.setDriveVelocity(60, percent);
  Monkey.setTurnVelocity(20, percent);
  Monkey.setTurnConstant(0.5);
  Monkey.setHeading(328, deg);
  Monkey.driveFor(reverse, 24, inches);
  Monkey.turnToHeading(0, deg);
  bananaEater.spin(forward, 10, volt);
  wait(0.5, sec);
  bananaEater.stop(coast);
  Monkey.turnToHeading(180, deg);
  Monkey.driveFor(forward, 10, inches);
  Monkey.driveFor(reverse, 5, inches);
  Monkey.turnToHeading(346, deg);
  Monkey.driveFor(forward, 6, inches);
  Monkey.turnToHeading(345, deg);
  bananaPusherVertical.set(true);
  Monkey.driveFor(forward, 15, inches);
  Monkey.turnToHeading(295, deg);
  bananaPusherVertical.set(false);
  Monkey.driveFor(forward, 19, inches);
  Monkey.turnToHeading(279, deg);
  Monkey.setDriveVelocity(40, percent);
  Monkey.driveFor(21, inches);

    
//   Monkey.drive(reverse);

  // Monkey.driveFor(reverse, 12, inches);
  // Monkey.turnToHeading(247.5, deg);
  // Monkey.driveFor(reverse, 10, inches);

  // //4.5 s, so - 2.5 = 2s

  // // bananaShooter.spin(reverse, flywheelSpeed, volt);
  // // wait(28, sec);
  // // bananaShooter.stop(coast);

  // //kill code later
  // bananaShooter.spin(reverse, flywheelSpeed, volt);
  // wait(2, sec);
  // bananaShooter.stop(coast);
  // //


  // //TIME FOR RUN IS 32s


  // Monkey.driveFor(fwd, 5, inches);
  // Monkey.turnToHeading(45, deg);
  // Monkey.driveFor(reverse, 60, inches);
  // Monkey.turnToHeading(91, deg);
  // Monkey.driveFor(reverse, 40, inches);
  // Monkey.driveFor(forward, 10, inches);
}

void cataSpin(){
  bananaShooter.spin(reverse, 12, volt);
}

void cataStop(){
  bananaShooter.stop(coast);
}

void usercontrol(void) {
  while (1) {
    bool isBeingPressed=true;
    bool RemoteControlCodeEnabled = true;
    bool toggle = true;
    // bool Controller1LeftShoulderControlMotorsStopped = true;
    // bool Controller1RightShoulderControlMotorsStopped = true;
    // bool DrivetrainLNeedsToBeStopped_Controller1 = true;
    // bool DrivetrainRNeedsToBeStopped_Controller1 = true;
    // bool toggle = true;
    if(RemoteControlCodeEnabled) {
      // int drivetrainLeftSideSpeed = realMonkey.Axis3.position() - realMonkey.Axis1.position();
      // int drivetrainRightSideSpeed = realMonkey.Axis4.position() + realMonkey.Axis2.position();
      // int drivetrainLeftSideSpeed = realMonkey.Axis3.position(pct);
      // int drivetrainRightSideSpeed = realMonkey.Axis1.position(pct);
      int drivetrainLeftSideSpeed = realMonkey.Axis3.position() + realMonkey.Axis1.position();
      int drivetrainRightSideSpeed = realMonkey.Axis3.position() - realMonkey.Axis1.position();
      int leftPowerCubed = drivetrainLeftSideSpeed * drivetrainLeftSideSpeed * drivetrainLeftSideSpeed / (100*100);
      int rightPowerCubed = drivetrainRightSideSpeed * drivetrainRightSideSpeed * drivetrainRightSideSpeed / (100*100);
      LDrive.spin(fwd, leftPowerCubed, pct);
      RDrive.spin(fwd, rightPowerCubed, pct);
      /*
      if (drivetrainLeftSideSpeed < 5 && drivetrainLeftSideSpeed > -5) {
        if (DrivetrainLNeedsToBeStopped_Controller1) {
          LDrive.stop(coast);
          DrivetrainLNeedsToBeStopped_Controller1 = false;
        }
      } else {
        // DrivetrainLNeedsToBeStopped_Controller1 = true;
      }
      if (drivetrainRightSideSpeed < 5 && drivetrainRightSideSpeed > -5) {
        if (DrivetrainRNeedsToBeStopped_Controller1) {
          RDrive.stop(coast);
          DrivetrainRNeedsToBeStopped_Controller1 = false;
        }
      } else {
        DrivetrainRNeedsToBeStopped_Controller1 = true;
      }
      if (DrivetrainLNeedsToBeStopped_Controller1) {
        LDrive.setVelocity(drivetrainLeftSideSpeed, percent);
        LDrive.spin(forward);
      }
      if (DrivetrainRNeedsToBeStopped_Controller1) {
        RDrive.setVelocity(drivetrainRightSideSpeed, percent);
        RDrive.spin(forward);
      }
      */
      // int leftPowerCubed = (drivetrainLeftSideSpeed*drivetrainLeftSideSpeed*drivetrainLeftSideSpeed) / (100*100);
      // int rightPowerCubed = (drivetrainRightSideSpeed*drivetrainRightSideSpeed*drivetrainRightSideSpeed) / (100*100);
      // leftMotorA.spin(reverse, leftPowerCubed, pct);
      // leftMotorB.spin(forward, leftPowerCubed, pct);
      // leftMotorC.spin(reverse, leftPowerCubed, pct);
      // rightMotorA.spin(forward, rightPowerCubed, pct);
      // rightMotorB.spin(reverse, rightPowerCubed, pct);
      // rightMotorC.spin(forward, rightPowerCubed, pct);
      
      

      if (realMonkey.ButtonL1.pressing()){
        bananaEater.spin(forward, 11, volt);
        isBeingPressed=false;
      }
      else if (realMonkey.ButtonL2.pressing()){
        bananaEater.spin(reverse, 11, volt);
        isBeingPressed=false;
      }
      else{
        bananaEater.stop(coast);
        isBeingPressed=true;
        //karthik is a monkey
      }

      //shooter control
      realMonkey.ButtonR1.pressed(cataSpin);
      realMonkey.ButtonR2.pressed(cataStop);

      
      if (realMonkey.ButtonY.pressing()){
        intakeRelease.set(true); 
      }
      if (realMonkey.ButtonA.pressing()){
        intakeRelease.set(false);
      }
      if (realMonkey.ButtonRight.pressing()){
        bananaPusherVertical.set(true);
      }
      if (realMonkey.ButtonLeft.pressing()){
        bananaPusherVertical.set(false);
      }

      if (realMonkey.ButtonUp.pressing()){
        horizontal_wing_1.set(true);
        horizontal_wing_2.set(true);
      }
      else if (realMonkey.ButtonDown.pressing()){
        horizontal_wing_1.set(false);
        horizontal_wing_2.set(false);
      }
      
      
      
      // if (realMonkey.ButtonUp.pressing()){
      //   horizontal_wing_2.set(true);
      // }
      // if (realMonkey.ButtonDown.pressing()){
      //   horizontal_wing_2.set(false);
      // }

    }
  }
    wait(20, msec);
  }


int main() {
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);
  pre_auton();
  while (true) {
    wait(100, msec);
  }
}
